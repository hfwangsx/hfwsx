import pandas as pd
def handleHistory(hist):
    histLabel={'S':1,'s':2,'H':3,'h':4,'A':5,'a':6,'D':7,'d':8,'F':9,'f':10,'R':11,'r':12,'C':13,'c':14,'I':15,'i':16,'T':17,'t':18,'^':19,'-':20}
    histList=[0]*13
    i=0
    for i in range(13):
        if i<hist.__len__():
            histList[i]=histLabel[hist[i]]
    return histList

def handleConn_state(conn_state):
    conn_stateLabel={'S0':1,'S1':2,'SF':3,'REJ':4,'S2':5,'S3':6,'RSTO':7,'RSTR':8,'RSTOS0':9,'RSTRH':10,'SH':11,'SHR':12,'OTH':13}
    return conn_stateLabel[conn_state]

def handleProto(proto):
    protoLabel={'tcp':1,'udp':2,'icmp':3}
    return protoLabel[proto]

def handleService(service):
    serviceLabel={'-':0,'dns':1,'http':2,'ssl':3,'ssh':4,'ftp':5,'mysql':6,'imap':7,'pop3':8,'teredo':9,'smtp':10,'sip':11,'krb_tcp':12}
    return serviceLabel[service]

def handleTunnel_parentsList(tunnel_parentsList):
    if tunnel_parentsList=='(empty)':
        return 0
    return 1

def handleDuration(duration):
    if duration=='-':
        return 0
    return int(float(duration))

def handleOrig_bytes(orig_bytes):
    if orig_bytes=='-':
        return 0
    return orig_bytes

def handleResp_bytes(orig_bytes):
    if orig_bytes=='-':
        return 0
    return orig_bytes

def handleLocal_orig(local_orig):
    if local_orig=='T':
        return 1
    return 0

def handleLocal_resp(local_resp):
    if local_resp=='T':
        return 1
    return 0
if __name__=='__main__':
    litLog=pd.read_csv(r'E:\pythonProject1\normal_02_03.csv')

    handledLog=pd.DataFrame(columns=['proto','service','duration','orig_bytes','resp_bytes','conn_state','local_orig','local_resp','missed_bytes','orig_pkts','resp_pkts','tunnel_parents','history0','history1','history2','history3','history4','history5','history6','history7','history8','history9','history10','history11','history12'])

    for index in litLog.index:
        tempLog=litLog.loc[index]
        tempHistList=handleHistory(tempLog.history)
        tempProto=handleProto(tempLog.proto)
        tempService=handleService(tempLog.service)
        tempDur=handleDuration(tempLog.duration)
        tempConnSta=handleConn_state(tempLog.conn_state)
        tempLocal_orig=handleLocal_orig(tempLog.local_orig)
        tempLocal_resp=handleLocal_resp(tempLog.local_resp)
        tempTunnel_parents=handleTunnel_parentsList(tempLog.tunnel_parents)
        tempOrig_bytes=handleOrig_bytes(tempLog.orig_bytes)
        tempResp_bytes=handleResp_bytes(tempLog.resp_bytes)
        tempHandle=pd.DataFrame([[tempProto,tempService,tempDur,tempOrig_bytes,tempResp_bytes,tempConnSta,tempLocal_orig,tempLocal_resp,tempLog.missed_bytes,tempLog.orig_pkts,tempLog.resp_pkts,tempTunnel_parents,tempHistList[0],tempHistList[1],tempHistList[2],tempHistList[3],tempHistList[4],tempHistList[5],tempHistList[6],tempHistList[7],tempHistList[8],tempHistList[9],tempHistList[10],tempHistList[11],tempHistList[12]]],
            columns=['proto','service','duration','orig_bytes','resp_bytes','conn_state','local_orig','local_resp','missed_bytes','orig_pkts','resp_pkts','tunnel_parents','history0','history1','history2','history3','history4','history5','history6','history7','history8','history9','history10','history11','history12'],)
        handledLog=handledLog.append(tempHandle)
        if index%500==0:
            print(index)
    handledLog.to_csv('handled_nor_02_03.csv',index=False)