import re
import os
import csv


fab=open(r'E:\pythonProject1\connLog\conn.02_00_00-03_00_00.log\NGSOC_label_02_','r')
fr=open(r'E:\pythonProject1\connLog\conn.02_00_00-03_00_00.log\conn.02_00_00-03_00_00.log','r',encoding='utf-8')
fwAbn=open('abnormal_02_03.csv', 'w')
fwNo=open('normal_02_03.csv', 'w')
ablist=[] #用来存放日志文件中为异常的数据行数
pattern=re.compile(r'\d+')
for i in range(20500):
    text=fab.readline()
    try:
        num=int(pattern.match(text).group(0))+8
        if num not in ablist:
            ablist.append(num)
    except:
        continue
ablist.sort()

indexAbn=0
for i in range(1,8600000):
    text = fr.readline()
    if i%5000==0:
        print(i)
    if i==ablist[indexAbn]:
        fwAbn.write(text)
        if indexAbn<10 :
            print(text,i)
        indexAbn+=1
    elif i>20 and i<30000:
        fwNo.write(text)




with open(os.path.join(os.path.dirname(__file__), 'file1')) as csvFile:
  rows = csv.reader(csvFile)
  with open(os.path.join(os.path.dirname(__file__), 'file2'), 'w') as f:
    writer = csv.writer(f)
    for row in rows:
      row.append('123465')
      writer.writerow(row)


def writeList2CSV(myList1,filePath):
    try:
        with open(filePath,'w',encoding='utf-8',newline='') as f:
            writer=csv.writer(f)
            for items in myList1:
                for item in items:
                    writer.writerow(item)
    except Exception :
        print("数据写入失败，请检查文件路径及文件编码是否正确")