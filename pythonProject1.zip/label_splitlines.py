import re

fte = open('E:\pythonProject1\test_label.csv', 'w')
f = open(r'E:\pythonProject1\connLog\conn.01_00_00-02_00_00.log\NGSOC_label_01_','r',encoding='utf-8')
label = dict()
i = 0
for line in f:
    num,class1,class2 = line.split(' ')
    print(class2)
    if class2 in label:
        label[class2] = label[class2] + 1
        fte.write(class2)
        break
f.close()


